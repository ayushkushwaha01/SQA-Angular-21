import { Component, OnInit, Input, ViewChild, ViewEncapsulation } from '@angular/core';
import { jwtDecode } from 'jwt-decode';
import { Router, NavigationEnd, RouterModule } from '@angular/router'; 
import { MatMenuTrigger } from '@angular/material/menu';
import { MenuService } from '../../../../services/menu.service';
import { Settings, SettingsService } from '../../../../services/settings.service';
import { FlexLayoutModule } from '@ngbracket/ngx-layout';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTooltipModule } from '@angular/material/tooltip';

@Component({
    selector: 'app-horizontal-menu',
    standalone: true,
    imports: [
        RouterModule,
        FlexLayoutModule,
        MatButtonModule,
        MatIconModule,
        MatTooltipModule
    ],
    templateUrl: './horizontal-menu.component.html',
    styleUrls: ['./horizontal-menu.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class HorizontalMenuComponent implements OnInit {
  @Input('menuParentId') menuParentId: any;
  public menuItems: Array<any>;
  public settings: Settings;
  @ViewChild(MatMenuTrigger) trigger: MatMenuTrigger;
  constructor(public settingsService: SettingsService, public menuService: MenuService, public router:Router) { 
    this.settings = this.settingsService.settings;
  }

  ngOnInit() {
    this.loadMenuItems();
  }

  private loadMenuItems() {
    let isSupplier = false;
    const token = sessionStorage.getItem('jwt_token') || localStorage.getItem('jwt_token');
    if (token) {
      try {
        const decoded: any = jwtDecode(token);
        const uType = decoded.UserType || decoded.userType;
        if (uType === 'Supplier') {
          isSupplier = true;
        }
      } catch (e) {}
    } else {
      isSupplier = this.router.url.startsWith('/app/supplier-login');
    }

    const allItems = isSupplier
      ? this.menuService.getSupplierMenuItems()
      : this.menuService.getHorizontalMenuItems();
    this.menuItems = allItems.filter(item => item.parentId == this.menuParentId);
  }

  ngAfterViewInit(){
    this.router.events.subscribe(event => {
      if (event instanceof NavigationEnd) {
        this.loadMenuItems();
        if (this.settings.fixedHeader) {
          const mainContent = document.getElementById('main-content');
          if (mainContent) { mainContent.scrollTop = 0; }
        } else {
          const drawer = document.getElementsByClassName('mat-drawer-content')[0] as HTMLElement;
          if (drawer) { drawer.scrollTop = 0; }
        }
      }
    });
  }

  public isItemActive(menu: any): boolean {
    if (!menu) return false;
    const currentUrl = (this.router.url || '').split('?')[0];
    if (menu.routerLink) {
      if (menu.routerLink === '/internal-portal/dashboard' || menu.routerLink === '/dashboard') {
        return (
          currentUrl === '/internal-portal/dashboard' ||
          currentUrl === '/internal-portal' ||
          currentUrl === '/dashboard' ||
          currentUrl === '/'
        );
      }
      if (menu.routerLink === '/app/supplier-login/dashboard') {
        return (
          currentUrl === '/app/supplier-login/dashboard' ||
          currentUrl === '/app/supplier-login'
        );
      }
      if (menu.routerLink === '/internal-portal/process') {
        return (
          (currentUrl === '/internal-portal/process' || currentUrl.startsWith('/internal-portal/process/'))
          && !currentUrl.startsWith('/internal-portal/process/setup')
        );
      }
      if (menu.routerLink === '/internal-portal/parts') {
        return (
          (currentUrl === '/internal-portal/parts' || currentUrl.startsWith('/internal-portal/parts/'))
          && !currentUrl.startsWith('/internal-portal/parts/setup')
        );
      }
      if (menu.id === 5 || menu.title === 'Setup') {
        return (
          currentUrl.startsWith('/internal-portal/process/setup')
          || currentUrl.startsWith('/internal-portal/parts/setup')
        );
      }
      return (
        currentUrl === menu.routerLink ||
        currentUrl.startsWith(menu.routerLink + '/') ||
        (menu.routerLink === '/manage-users' && currentUrl.startsWith('/manage-users'))
      );
    }
    if (menu.id === 6 || menu.title === 'Admin') {
      return currentUrl.startsWith('/manage-users') || currentUrl.startsWith('/admin');
    }
    return false;
  }
}