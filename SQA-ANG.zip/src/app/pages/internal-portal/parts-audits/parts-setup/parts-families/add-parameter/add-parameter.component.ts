// // import { Component, Inject, OnInit } from '@angular/core';
// // import { FormBuilder, FormGroup, Validators } from '@angular/forms';
// // import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
// // import { LookupService } from 'src/app/pages/admin/lookup/lookup.service';
// // import { SetupService } from 'src/app/pages/setup/setup.service';
// // import { AlertService } from 'src/app/shared/alert.service';

// // @Component({
// //   standalone: false,
// //   selector: 'app-add-parameter',
// //   templateUrl: './add-parameter.component.html',
// //   styleUrls: ['./add-parameter.component.scss']
// // })
// // export class AddParameterComponent implements OnInit {


// //   isEditMode: boolean = false;

// //   isDragOver = false;
// //   selectedFileName: string = '';
// //   selectedFile: File | null = null;
// //   myGroup!: FormGroup;

// //   partFamilyId!: number;
// //   constructor(
// //     private dialogRef: MatDialogRef<AddParameterComponent>,
// //     @Inject(MAT_DIALOG_DATA) public data: any, private alertService: AlertService, private _setupService: SetupService, private fb: FormBuilder,
// //     private lookupService: LookupService
// //   ) { }

// //   ngOnInit(): void {
// //     this.partFamilyId = this.data.partFamilyId;
// //     console.log(this.partFamilyId);
// //     this.formInit(this.data);
// //     this.getLookups();

// //     this.getPartAuditCategories();

// //   }


// //   formInit(data: any) {
// //     this.myGroup = this.fb.group({

// //       ParameterId: [data?.parameterId || 0],
// //       PartFamilyId: [data?.partFamilyId || 0],

// //       PartId: [
// //         data?.partId || null,
// //         Validators.required
// //       ],

// //       ParmeterName: [
// //         data?.parmeterName || '',
// //         Validators.required
// //       ],

// //       Spec: [
// //         data?.spec || ''
// //       ],

// //       // Min: [
// //       //   data?.min || ''
// //       // ],

// //       // Max: [
// //       //   data?.max || ''
// //       // ],
// //       Min: [
// //         data?.min || '',
// //         [Validators.pattern(/^\d+(\.\d+)?$/)]
// //       ],

// //       Max: [
// //         data?.max || '',
// //         [Validators.pattern(/^\d+(\.\d+)?$/)]
// //       ],

// //       Method: [
// //         data?.method || ''
// //       ],
// //       UnitId: [
// //         data?.unitId || null,
// //         Validators.required
// //       ]

// //     });
// //   }

// //   get f() {
// //     return this.myGroup.controls;
// //   }
// //   allowNumericOnly(event: KeyboardEvent): boolean {
// //     const input = event.target as HTMLInputElement;
// //     const char = event.key;

// //     // Allow digits
// //     if (/[0-9]/.test(char)) {
// //       return true;
// //     }

// //     // Allow one decimal point
// //     if (char === '.' && !input.value.includes('.')) {
// //       return true;
// //     }

// //     // Allow control keys
// //     if (
// //       char === 'Backspace' ||
// //       char === 'Delete' ||
// //       char === 'ArrowLeft' ||
// //       char === 'ArrowRight' ||
// //       char === 'Tab'
// //     ) {
// //       return true;
// //     }

// //     event.preventDefault();
// //     return false;
// //   }
// //   lookups: any[] = [];

// //   getLookups() {
// //     this.lookupService.getLookups().subscribe((res: any) => {
// //       if (res.success) {
// //         this.lookups = res.data.filter((x: any) => x.codeId === 3);
// //       }
// //     });
// //   }


// //   UpsertParameter(): void {

// //     if (this.myGroup.invalid) {
// //       this.myGroup.markAllAsTouched();
// //       return;
// //     }

// //     this._setupService.upsertParameter(this.myGroup.value)
// //       .subscribe({
// //         next: (res: any) => {

// //           if (res.success) {
// //             this.alertService.createAlert(res.message, 1);
// //             this.dialogRef.close(true);
// //           }
// //           else {
// //             this.alertService.createAlert(res.message, 0);
// //           }

// //         },
// //         error: (err) => {
// //           console.error(err);

// //           this.alertService.createAlert(
// //             err?.error?.message || 'Something went wrong.',
// //             0
// //           );
// //         }
// //       });
// //   }



// //   partAuditCategories: any[] = [];
// //   getPartAuditCategories() {
// //     this._setupService.getPartAuditCategories(null)
// //       .subscribe((res: any) => {
// //         if (res.success) {

// //           this.partAuditCategories = res.data.data;

// //         }
// //       });
// //   }



// //   close(): void {
// //     this.dialogRef.close();
// //   }



// // }



// import { Component, Inject, OnInit } from '@angular/core';
// import { FormBuilder, FormGroup, Validators } from '@angular/forms';
// import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
// import { LookupService } from 'src/app/pages/admin/lookup/lookup.service';
// import { SetupService } from 'src/app/pages/setup/setup.service';
// import { AlertService } from 'src/app/shared/alert.service';

// @Component({
//   standalone: false,
//   selector: 'app-add-parameter',
//   templateUrl: './add-parameter.component.html',
//   styleUrls: ['./add-parameter.component.scss']
// })
// export class AddParameterComponent implements OnInit {

//   isEditMode: boolean = false;
//   isDragOver = false;
//   selectedFileName: string = '';
//   selectedFile: File | null = null;
//   myGroup!: FormGroup;

//   partFamilyId!: number;
  
//   constructor(
//     private dialogRef: MatDialogRef<AddParameterComponent>,
//     @Inject(MAT_DIALOG_DATA) public data: any, 
//     private alertService: AlertService, 
//     private _setupService: SetupService, 
//     private fb: FormBuilder,
//     private lookupService: LookupService
//   ) { }

//   ngOnInit(): void {
//     this.partFamilyId = this.data.partFamilyId;
//     console.log("Part Family ID:", this.partFamilyId, "Stage:", this.data.stage);
    
//     this.formInit(this.data);
//     this.getLookups();
//     this.getPartAuditCategories();
//   }

//   formInit(data: any) {
//     this.myGroup = this.fb.group({
//       ParameterId: [data?.parameterId || 0],
//       PartFamilyId: [data?.partFamilyId || 0],
      
//       // 🔥 ADDED THIS LINE: Capture the stage passed from the grid tab
//       Stage: [data?.stage || ''], 

//       PartId: [
//         data?.partId || null,
//         Validators.required
//       ],
//       ParmeterName: [
//         data?.parmeterName || '',
//         Validators.required
//       ],
//       Spec: [
//         data?.spec || ''
//       ],
//       Min: [
//         data?.min || '',
//         [Validators.pattern(/^\d+(\.\d+)?$/)]
//       ],
//       Max: [
//         data?.max || '',
//         [Validators.pattern(/^\d+(\.\d+)?$/)]
//       ],
//       Method: [
//         data?.method || ''
//       ],
//       UnitId: [
//         data?.unitId || null,
//         Validators.required
//       ]
//     });
//   }

//   get f() {
//     return this.myGroup.controls;
//   }
  
//   allowNumericOnly(event: KeyboardEvent): boolean {
//     const input = event.target as HTMLInputElement;
//     const char = event.key;

//     // Allow digits
//     if (/[0-9]/.test(char)) {
//       return true;
//     }

//     // Allow one decimal point
//     if (char === '.' && !input.value.includes('.')) {
//       return true;
//     }

//     // Allow control keys
//     if (
//       char === 'Backspace' ||
//       char === 'Delete' ||
//       char === 'ArrowLeft' ||
//       char === 'ArrowRight' ||
//       char === 'Tab'
//     ) {
//       return true;
//     }

//     event.preventDefault();
//     return false;
//   }
  
//   lookups: any[] = [];

//   getLookups() {
//     this.lookupService.getLookups().subscribe((res: any) => {
//       if (res.success) {
//         this.lookups = res.data.filter((x: any) => x.codeId === 3);
//       }
//     });
//   }

//   UpsertParameter(): void {
//     if (this.myGroup.invalid) {
//       this.myGroup.markAllAsTouched();
//       return;
//     }

//     // The Stage is now automatically included inside this.myGroup.value
//     this._setupService.upsertParameter(this.myGroup.value)
//       .subscribe({
//         next: (res: any) => {
//           if (res.success) {
//             this.alertService.createAlert(res.message, 1);
//             this.dialogRef.close(true);
//           }
//           else {
//             this.alertService.createAlert(res.message, 0);
//           }
//         },
//         error: (err) => {
//           console.error(err);
//           this.alertService.createAlert(
//             err?.error?.message || 'Something went wrong.',
//             0
//           );
//         }
//       });
//   }

//   partAuditCategories: any[] = [];
  
//   getPartAuditCategories() {
//     this._setupService.getPartAuditCategories(null)
//       .subscribe((res: any) => {
//         if (res.success) {
//           this.partAuditCategories = res.data.data;
//         }
//       });
//   }

//   close(): void {
//     this.dialogRef.close();
//   }
// }


import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { LookupService } from 'src/app/pages/admin/lookup/lookup.service';
import { SetupService } from 'src/app/pages/setup/setup.service';
import { AlertService } from 'src/app/shared/alert.service';

@Component({
  standalone: false,
  selector: 'app-add-parameter',
  templateUrl: './add-parameter.component.html',
  styleUrls: ['./add-parameter.component.scss']
})
export class AddParameterComponent implements OnInit {

  isEditMode: boolean = false;
  isDragOver = false;
  selectedFileName: string = '';
  selectedFile: File | null = null;
  myGroup!: FormGroup;
  partFamilyId!: number;
  stagesList: any[] = []; // Array to hold stages for dropdown

  constructor(
    private dialogRef: MatDialogRef<AddParameterComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any, 
    private alertService: AlertService, 
    private _setupService: SetupService, 
    private fb: FormBuilder,
    private lookupService: LookupService
  ) { }

  ngOnInit(): void {
    this.partFamilyId = this.data.partFamilyId;
    this.stagesList = this.data.stagesList || []; // Capture stages list from data
    
    this.formInit(this.data);
    this.getLookups();
    this.getPartAuditCategories();
  }

  formInit(data: any) {
    this.myGroup = this.fb.group({
      ParameterId: [data?.parameterId || 0],
      PartFamilyId: [data?.partFamilyId || 0],
      Stage: [data?.stage || '', Validators.required], // Stage control with validation

      PartId: [data?.partId || null, Validators.required],
      ParmeterName: [data?.parmeterName || '', Validators.required],
      Spec: [data?.spec || ''],
      Min: [data?.min || '', [Validators.pattern(/^\d+(\.\d+)?$/)]],
      Max: [data?.max || '', [Validators.pattern(/^\d+(\.\d+)?$/)]],
      Method: [data?.method || ''],
      UnitId: [data?.unitId || null, Validators.required]
    });
  }

  get f() { return this.myGroup.controls; }

  allowNumericOnly(event: KeyboardEvent): boolean {
    const input = event.target as HTMLInputElement;
    const char = event.key;
    if (/[0-9]/.test(char)) return true;
    if (char === '.' && !input.value.includes('.')) return true;
    if (['Backspace', 'Delete', 'ArrowLeft', 'ArrowRight', 'Tab'].includes(char)) return true;
    event.preventDefault();
    return false;
  }
  
  lookups: any[] = [];
  getLookups() {
    this.lookupService.getLookups().subscribe((res: any) => {
      if (res.success) {
        this.lookups = res.data.filter((x: any) => x.codeId === 3);
      }
    });
  }

  UpsertParameter(): void {
    if (this.myGroup.invalid) {
      this.myGroup.markAllAsTouched();
      return;
    }

    this._setupService.upsertParameter(this.myGroup.value)
      .subscribe({
        next: (res: any) => {
          if (res.success) {
            this.alertService.createAlert(res.message, 1);
            this.dialogRef.close(true);
          } else {
            this.alertService.createAlert(res.message, 0);
          }
        },
        error: (err) => {
          console.error(err);
          this.alertService.createAlert(err?.error?.message || 'Something went wrong.', 0);
        }
      });
  }

  partAuditCategories: any[] = [];
  getPartAuditCategories() {
    this._setupService.getPartAuditCategories(null)
      .subscribe((res: any) => {
        if (res.success) {
          this.partAuditCategories = res.data.data;
        }
      });
  }

  close(): void { this.dialogRef.close(); }
}