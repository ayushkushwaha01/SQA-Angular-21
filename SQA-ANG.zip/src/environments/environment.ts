// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  // apiUrl: 'https://localhost:7202/api/'
  //  apiUrl: 'https://qasqaapi.optionmatrix.co.in/api/'
  apiUrl: 'https://sqaapi.optionmatrix.in/api/'
  
};
